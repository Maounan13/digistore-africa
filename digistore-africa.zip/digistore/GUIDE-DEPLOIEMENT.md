# 🌍 DigiStore Africa — Guide de déploiement complet

## Structure du projet

```
digistore/
├── server.js          ← Backend Node.js (API + emails)
├── package.json
├── render.yaml        ← Config déploiement Render.com
├── .env.example       ← Variables d'environnement (à copier en .env)
├── data/
│   ├── products.json  ← Catalogue produits (à modifier)
│   └── orders.json    ← Commandes (auto-géré)
├── emails/
│   └── delivery.html  ← Template email livraison
└── public/
    ├── index.html     ← Page principale
    ├── success.html   ← Page confirmation paiement
    ├── css/style.css  ← Styles
    └── js/app.js      ← JavaScript frontend
```

---

## 🚀 ÉTAPE 1 — Mettre en ligne sur Render.com (GRATUIT)

### 1.1 Créer un compte GitHub (si pas encore fait)
→ https://github.com

### 1.2 Créer un dépôt GitHub
1. Clique sur **New repository**
2. Nom : `digistore-africa`
3. **Public** ou Private (les deux marchent)
4. Clique **Create repository**

### 1.3 Uploader les fichiers
Depuis ton ordinateur, ouvre le terminal dans le dossier `digistore/` :
```bash
git init
git add .
git commit -m "DigiStore Africa v1.0"
git branch -M main
git remote add origin https://github.com/TON_USERNAME/digistore-africa.git
git push -u origin main
```

### 1.4 Déployer sur Render.com
1. Va sur → https://render.com et crée un compte (gratuit)
2. Clique **New** → **Web Service**
3. Connecte ton compte GitHub
4. Sélectionne le repo `digistore-africa`
5. Render détectera automatiquement la config
6. Clique **Create Web Service**
7. ⏳ Attends 3-5 minutes → ton site sera live !

**Ton URL sera :** `https://digistore-africa.onrender.com`

---

## ✉️ ÉTAPE 2 — Configurer les emails (livraison automatique)

### Option A : Brevo (RECOMMANDÉ — 300 emails/jour gratuit)
1. Crée un compte sur → https://brevo.com
2. Va dans **SMTP & API** → **SMTP Settings**
3. Copie les identifiants SMTP

Dans Render → **Environment** → ajoute ces variables :
```
SMTP_HOST=smtp-relay.brevo.com
SMTP_PORT=587
SMTP_USER=ton@email.com
SMTP_PASS=xsmtp-xxxxxxxxxxxx (clé Brevo)
EMAIL_FROM=noreply@digistore-africa.com
EMAIL_FROM_NAME=DigiStore Africa
SITE_URL=https://digistore-africa.onrender.com
```

### Option B : Gmail (plus simple)
1. Active la **validation en 2 étapes** sur ton compte Google
2. Va dans Compte Google → Sécurité → **Mots de passe des applications**
3. Génère un mot de passe pour "Mail"

Variables :
```
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=tonemail@gmail.com
SMTP_PASS=xxxx xxxx xxxx xxxx (mot de passe d'application)
```

---

## 💳 ÉTAPE 3 — Configurer les paiements CinetPay

CinetPay supporte : Wave, MTN MoMo, Orange Money, Airtel Money, Moov, Visa/Mastercard
Pays : Cameroun, Côte d'Ivoire, Sénégal, Burkina Faso, Mali, Togo, Guinée, Congo...

### 3.1 Créer un compte CinetPay
→ https://cinetpay.com → S'inscrire (gratuit)

### 3.2 Récupérer les clés API
→ Dashboard CinetPay → Paramètres → API Keys

### 3.3 Ajouter dans Render (Environment Variables)
```
CINETPAY_APIKEY=ta_cle_api
CINETPAY_SITE_ID=ton_site_id
```

### 3.4 Configurer le webhook dans CinetPay
URL de notification : `https://digistore-africa.onrender.com/api/orders/webhook`

---

## 📦 ÉTAPE 4 — Ajouter tes vrais produits

Modifie le fichier `data/products.json` :

```json
{
  "id": "prod_001",
  "title": "Nom de ton produit",
  "category": "Formation",
  "emoji": "🎓",
  "price": 9900,
  "currency": "XOF",
  "badge": "🔥 TOP",
  "badgeType": "hot",
  "description": "Description du produit",
  "includes": ["Élément 1", "Élément 2"],
  "downloadUrl": "https://drive.google.com/file/d/TON_ID/view",
  "color": "linear-gradient(135deg,#1a1a35,#2a1a50)",
  "featured": true,
  "sales": 100
}
```

**Pour héberger tes fichiers :**
- Google Drive (lien de partage public)
- Dropbox (lien de partage)
- AWS S3 (pour les grandes équipes)

---

## 🔧 ÉTAPE 5 — Personnaliser le site

### Changer le nom
Dans `public/index.html`, remplace "DigiStore" par ton nom de marque.

### Changer les couleurs
Dans `public/css/style.css`, modifie les variables CSS :
```css
:root {
  --gold: #F5A623;  /* couleur principale */
  --green: #06C167; /* couleur secondaire */
  --dark: #0D0D1A;  /* fond */
}
```

### Changer le numéro WhatsApp
Cherche `237600000000` et remplace par ton vrai numéro.

---

## 📊 Fonctionnalités incluses

✅ Catalogue produits dynamique (chargé depuis l'API)
✅ Filtrage par catégorie
✅ Modal paiement avec sélection du mode
✅ Intégration CinetPay (Wave, MTN, Orange, Airtel, Visa)
✅ Livraison email automatique après paiement
✅ Template email professionnel
✅ Page de confirmation de commande
✅ Mode démo (sans clé API)
✅ Rate limiting (protection anti-spam)
✅ Design responsive mobile/tablette/desktop
✅ 8 pays africains couverts

---

## 🆘 Support

En cas de problème, contactez-nous via WhatsApp.
