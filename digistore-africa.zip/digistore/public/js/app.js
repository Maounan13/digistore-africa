/* ============================================
   DigiStore Africa — Main JS
   ============================================ */

const API = '';  // empty = same origin

// ─── State ────────────────────────────────────
let products = [];
let selectedProduct = null;
let selectedPayMethod = null;

// ─── DOM Ready ────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  loadProducts();
  setupModal();
  setupNewsletter();
});

// ─── Load products from API ───────────────────
async function loadProducts() {
  try {
    const res  = await fetch(`${API}/api/products`);
    const json = await res.json();
    products = json.data || [];
    renderProducts(products);
  } catch (e) {
    console.error('Failed to load products:', e);
  }
}

// ─── Render product cards ─────────────────────
function renderProducts(list) {
  const grid = document.getElementById('prodGrid');
  if (!grid) return;
  grid.innerHTML = '';

  list.forEach(p => {
    const badgeClass = { hot: 'badge-hot', new: 'badge-new', pack: 'badge-pack' }[p.badgeType] || 'badge-hot';
    grid.innerHTML += `
      <div class="prod-card" onclick="openBuyModal('${p.id}')">
        <div class="prod-thumb" style="background:${p.color}">
          ${p.emoji}
          <div class="prod-badge ${badgeClass}">${p.badge}</div>
        </div>
        <div class="prod-body">
          <div class="prod-cat">${p.category}</div>
          <div class="prod-title">${p.title}</div>
          <div class="prod-delivery">⚡ Livraison instantanée par email</div>
          <div class="prod-footer">
            <div>
              <div class="prod-price">${p.price.toLocaleString('fr-FR')} <small>FCFA</small></div>
              <div class="prod-sales">${p.sales} ventes</div>
            </div>
            <button class="btn btn-primary btn-sm" onclick="event.stopPropagation();openBuyModal('${p.id}')">Acheter</button>
          </div>
        </div>
      </div>`;
  });
}

// ─── Filter by category ───────────────────────
function filterCat(cat) {
  const filtered = cat === 'all'
    ? products
    : products.filter(p => p.category.toLowerCase().includes(cat));
  renderProducts(filtered);
  document.querySelector('.products-section')?.scrollIntoView({ behavior: 'smooth' });
}
window.filterCat = filterCat;

// ─── Modal ────────────────────────────────────
function setupModal() {
  const overlay = document.getElementById('modalOverlay');
  overlay?.addEventListener('click', e => { if (e.target === overlay) closeModal(); });
}

function openBuyModal(productId) {
  selectedProduct = products.find(p => p.id === productId);
  if (!selectedProduct) return;
  selectedPayMethod = null;

  document.getElementById('modalProductEmoji').textContent = selectedProduct.emoji;
  document.getElementById('modalProductTitle').textContent = selectedProduct.title;
  document.getElementById('modalProductPrice').textContent = selectedProduct.price.toLocaleString('fr-FR') + ' FCFA';
  document.querySelectorAll('.pay-method').forEach(el => el.classList.remove('selected'));
  document.getElementById('modalOverlay').classList.add('open');
  document.body.style.overflow = 'hidden';
}
window.openBuyModal = openBuyModal;

function closeModal() {
  document.getElementById('modalOverlay').classList.remove('open');
  document.body.style.overflow = '';
}
window.closeModal = closeModal;

function selectPayMethod(el, method) {
  document.querySelectorAll('.pay-method').forEach(e => e.classList.remove('selected'));
  el.classList.add('selected');
  selectedPayMethod = method;
}
window.selectPayMethod = selectPayMethod;

// ─── Initiate payment ─────────────────────────
async function submitPayment() {
  const email = document.getElementById('buyEmail').value.trim();
  const phone = document.getElementById('buyPhone').value.trim();

  if (!selectedPayMethod) { showToast('⚠️ Choisissez un mode de paiement', 'error'); return; }
  if (!email || !email.includes('@')) { showToast('⚠️ Entrez un email valide', 'error'); return; }
  if (!phone || phone.length < 8)    { showToast('⚠️ Entrez un numéro de téléphone valide', 'error'); return; }

  const btn = document.getElementById('payBtn');
  btn.disabled = true;
  btn.innerHTML = '<span class="loader"></span> Traitement...';

  try {
    const res  = await fetch(`${API}/api/orders/initiate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ productId: selectedProduct.id, email, phone, paymentMethod: selectedPayMethod }),
    });
    const json = await res.json();

    if (json.success) {
      if (json.paymentUrl) {
        // Real CinetPay redirect
        window.location.href = json.paymentUrl;
      } else if (json.demoMode) {
        // Demo mode
        closeModal();
        showToast('🎉 Mode démo — Simulation du paiement...', 'success');
        setTimeout(() => { window.location.href = json.simulateUrl; }, 1500);
      }
    } else {
      showToast('❌ Erreur: ' + (json.message || 'Réessayez'), 'error');
      btn.disabled = false;
      btn.textContent = '🔒 Confirmer le paiement';
    }
  } catch (err) {
    showToast('❌ Erreur de connexion. Réessayez.', 'error');
    btn.disabled = false;
    btn.textContent = '🔒 Confirmer le paiement';
  }
}
window.submitPayment = submitPayment;

// ─── Newsletter ───────────────────────────────
function setupNewsletter() {
  const form = document.getElementById('nlForm');
  form?.addEventListener('submit', e => {
    e.preventDefault();
    const email = form.querySelector('input').value.trim();
    if (!email || !email.includes('@')) { showToast('⚠️ Email invalide', 'error'); return; }
    showToast('✅ Inscription réussie ! Merci.', 'success');
    form.reset();
  });
}

// ─── Toast notification ───────────────────────
function showToast(msg, type = 'success') {
  const t = document.createElement('div');
  t.className = `toast ${type}`;
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 4000);
}
window.showToast = showToast;

// ─── Smooth scroll for CTA ────────────────────
function scrollToCatalogue() {
  document.querySelector('.products-section')?.scrollIntoView({ behavior: 'smooth' });
}
window.scrollToCatalogue = scrollToCatalogue;

function scrollToHow() {
  document.querySelector('.how-section')?.scrollIntoView({ behavior: 'smooth' });
}
window.scrollToHow = scrollToHow;
